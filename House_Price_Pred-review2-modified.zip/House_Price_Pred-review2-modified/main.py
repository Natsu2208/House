import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
import pickle

# Load the data
data = pd.read_csv('data3.csv')

# Extract features and target variable
most_correlated = data.corr(numeric_only=True).abs()
data = data.loc[:, most_correlated.index]
data_features = data.columns
x = data[data_features].copy()
y = data['actualrent']

# Split data into train and test sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=100)

# Train RandomForestRegressor
model = RandomForestRegressor()
param_grid = {
    'n_estimators': [50, 75, 100],
    'max_depth': [5, 7],
    'min_samples_split': [5, 10],
    'max_features': ['sqrt', 'log2']
}
grid_search = GridSearchCV(model, param_grid, cv=5, scoring='r2')
grid_search.fit(x_train, y_train)

# Get best parameters and model
best_params = grid_search.best_params_
best_model = grid_search.best_estimator_

# Evaluate model
y_pred = best_model.predict(x_test)
r2 = r2_score(y_test, y_pred)

print("Best Parameters: ", best_params)
print("R-squared : ", r2)

# Save the model
pickle.dump(best_model, open('model.pkl', 'wb'))

# Load the model
model = pickle.load(open('model.pkl', 'rb'))

def predict_rent(features):
    # Preprocess city feature
    city_encoded = preprocess_city(features[2])
    # Predict rent using the model
    prediction = model.predict([features[:2] + [city_encoded] + features[3:]])[0]
    return prediction

def find_similar_streets(city, rent):
    # Filter streets with predicted rents equal to or less than the predicted rent
    similar_streets = data[(data['city'] == city) & (data['actualrent'] <= rent)]
    return similar_streets[['city', 'street', 'actualrent']]

def preprocess_city(city):
    if city == 'kolkata':
        return 0
    elif city == 'salem':
        return 1
    elif city == 'bangalore':
        return 2
    elif city == 'chennai':
        return 3
    elif city == 'coimbatore':
        return 4
    elif city == 'dindigul':
        return 5


