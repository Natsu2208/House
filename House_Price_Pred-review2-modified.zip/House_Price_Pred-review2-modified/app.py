from flask import Flask, render_template, request, redirect, url_for
import pickle
import pandas as pd

app = Flask(__name__)

# Load the model
model = pickle.load(open('model.pkl', 'rb'))

# Load the data
data = pd.read_csv('data3.csv')

# Define route for index/home page
@app.route('/')
def index():
    return render_template('index.html')

# Define route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get form data
    city = request.form['city']
    property_type = request.form['propertytype']
    currentsupply = request.form['currentsupply']
    watersupply = request.form['watersupply']
    parking = request.form['parking']
    
    # Preprocess form data
    city_encoded = preprocess_city(city)
    property_type_encoded = preprocess_property_type(property_type)
    parking_encoded = preprocess_binary(parking)
    currentsupply_encoded = preprocess_binary(currentsupply)
    watersupply_encoded = preprocess_binary(watersupply)
    
    # Combine features into a single array for prediction
    features = [city_encoded, property_type_encoded, parking_encoded, currentsupply_encoded, watersupply_encoded]
    
    # Make prediction
    prediction = model.predict([features])[0]
    
    # Filter similar streets
    similar_streets_info = filter_similar_streets(prediction, city)
    
    # Redirect to result page with the prediction result and similar streets
    return redirect(url_for('result', prediction=prediction, similar_streets_info=similar_streets_info.to_json()))

def filter_similar_streets(prediction, city):
    # Filter streets with predicted rents similar to the predicted value for the selected city
    similar_streets = data[(data['actualrent'] < prediction) & (data['city'] == city)]
    return similar_streets[['city', 'street', 'actualrent']]

# Define route for result page
@app.route('/result')
def result():
    prediction = request.args.get('prediction')
    similar_streets_info = pd.read_json(request.args.get('similar_streets_info'))
    return render_template('result.html', prediction=prediction, similar_streets_info=similar_streets_info)

def preprocess_city(city):
    if city.lower() == 'kolkata':
        return 0
    elif city.lower() == 'salem':
        return 1
    elif city.lower() == 'bangalore':
        return 2
    elif city.lower() == 'chennai':
        return 3
    elif city.lower() == 'coimbatore':
        return 4
    elif city.lower() == 'dindigul':
        return 5
    else:
        return -1  # Handle unknown cities


def preprocess_property_type(property_type):
    if property_type == 'apartment':
        return 0
    elif property_type == 'house':
        return 1

def preprocess_binary(value):
    if value.lower() == 'yes':
        return 1
    elif value.lower() == 'no':
        return 0

if __name__ == "__main__":
    app.run(debug=True)
